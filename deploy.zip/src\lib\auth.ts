import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

export const authOptions: NextAuthOptions = {
    providers: [
        CredentialsProvider({
            name: "Credentials",
            credentials: {
                username: { label: "Email", type: "text", placeholder: "admin@wellness.com" },
                password: { label: "Password", type: "password" }
            },
            async authorize(credentials) {
                if (!credentials?.username || !credentials?.password) {
                    return null;
                }

                const { prisma } = await import('./prisma');
                const bcrypt = await import('bcryptjs');

                // Fallback for initial setup if no users exist
                const userCount = await prisma.user.count();
                if (userCount === 0 && credentials.username === 'admin' && credentials.password === 'admin') {
                    const hashedPassword = await bcrypt.hash('admin', 10);
                    const newUser = await prisma.user.create({
                        data: {
                            name: 'Administrator',
                            email: 'admin', // taking admin as email for fallback
                            password: hashedPassword,
                            role: 'ADMIN'
                        }
                    });
                    return { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role };
                }

                const user = await prisma.user.findUnique({
                    where: { email: credentials.username }
                });

                if (!user || !user.password) {
                    return null;
                }

                const isPasswordValid = await bcrypt.compare(credentials.password, user.password);

                if (!isPasswordValid) {
                    return null;
                }

                return { id: user.id, name: user.name, email: user.email, role: user.role };
            }
        })
    ],
    session: {
        strategy: "jwt",
    },
    callbacks: {
        jwt: async ({ token, user }) => {
            if (user) {
                token.role = (user as any).role;
            }
            return token;
        },
        session: async ({ session, token }) => {
            if (session?.user) {
                (session.user as any).role = token.role;
            }
            return session;
        }
    },
    pages: {
        signIn: "/login",
    }
};
