import { prisma } from '@/lib/prisma';
import Link from 'next/link';
import { Mail, Calendar, ArrowRight } from 'lucide-react';

export const metadata = {
    title: 'Our Team | Mind & Wellness',
}

export default async function DoctorsUserPage() {
    const doctors = await prisma.doctor.findMany({
        orderBy: { name: 'asc' },
        include: { specialties: true }
    });

    return (
        <main className="section">
            <div className="container" style={{ textAlign: 'center', marginBottom: '4rem' }}>
                <h1 className="heading-lg">Meet Our Wellness Experts</h1>
                <p style={{ color: 'var(--text-secondary)', maxWidth: '600px', margin: '0 auto' }}>
                    Our team is composed of highly qualified, compassionate professionals dedicated to guiding your journey to inner peace.
                </p>
            </div>

            <div className="container">
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '3rem' }}>
                    {doctors.length === 0 ? (
                        <div style={{ textAlign: 'center', gridColumn: '1 / -1', padding: '4rem', color: 'var(--text-secondary)' }}>
                            We are currently updating our team roster. Please check back soon.
                        </div>
                    ) : (
                        doctors.map((doc) => (
                            <div
                                key={doc.id}
                                className="glass-panel"
                                style={{
                                    borderRadius: 'var(--radius-lg)',
                                    overflow: 'hidden',
                                    transition: 'var(--transition-smooth)',
                                    display: 'flex',
                                    flexDirection: 'column'
                                }}
                            >
                                <div style={{
                                    height: '240px',
                                    backgroundColor: 'var(--primary-light)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    overflow: 'hidden'
                                }}>
                                    {doc.imageUrl ? (
                                        <img src={doc.imageUrl} alt={doc.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                    ) : (
                                        <div style={{ width: '120px', height: '120px', borderRadius: '50%', backgroundColor: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '3rem', color: 'var(--primary-dark)' }}>
                                            {doc.name.charAt(0)}
                                        </div>
                                    )}
                                </div>

                                <div style={{ padding: '2rem', flex: 1, display: 'flex', flexDirection: 'column' }}>
                                    <h3 style={{ fontSize: '1.5rem', marginBottom: '0.25rem' }}>{doc.name}</h3>
                                    <p style={{ color: 'var(--primary-dark)', fontWeight: 500, fontSize: '0.875rem', marginBottom: '1rem' }}>
                                        {doc.title || 'Wellness Professional'}
                                    </p>

                                    {doc.specialties && doc.specialties.length > 0 && (
                                        <div style={{ marginBottom: '1.5rem', display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                                            {doc.specialties.slice(0, 2).map(spec => (
                                                <span key={spec.id} style={{ fontSize: '0.75rem', padding: '0.2rem 0.6rem', backgroundColor: 'var(--bg-color)', border: '1px solid var(--glass-border)', borderRadius: '1rem' }}>
                                                    {spec.name}
                                                </span>
                                            ))}
                                            {doc.specialties.length > 2 && <span style={{ fontSize: '0.75rem', padding: '0.2rem 0.6rem' }}>+{doc.specialties.length - 2} more</span>}
                                        </div>
                                    )}

                                    <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem', marginBottom: '2rem', lineHeight: 1.5, flex: 1 }}>
                                        {doc.bio ? (doc.bio.length > 100 ? `${doc.bio.substring(0, 100)}...` : doc.bio) : 'Dedicated to providing holistic care and supporting your wellness journey.'}
                                    </p>

                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                                        <Link href={`/doctors/${doc.id}`} className="btn btn-outline" style={{ display: 'flex', justifyContent: 'center', gap: '0.5rem', padding: '0.75rem' }}>
                                            View Profile <ArrowRight size={16} />
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </main>
    );
}
