'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';

export async function createDoctor(formData: FormData) {
    const name = formData.get('name')?.toString();
    const title = formData.get('title')?.toString();
    const bio = formData.get('bio')?.toString();
    const imageUrl = formData.get('imageUrl')?.toString();
    const specialtyIds = formData.getAll('specialties').map(String);

    if (!name) throw new Error('Name is required');

    await prisma.doctor.create({
        data: {
            name,
            title,
            bio,
            imageUrl,
            specialties: specialtyIds.length > 0 ? {
                connect: specialtyIds.map(id => ({ id }))
            } : undefined
        }
    });

    revalidatePath('/admin/doctors');
    revalidatePath('/doctors');
    redirect('/admin/doctors');
}

export async function updateDoctor(formData: FormData) {
    const id = formData.get('id')?.toString();
    const name = formData.get('name')?.toString();
    const title = formData.get('title')?.toString();
    const bio = formData.get('bio')?.toString();
    const imageUrl = formData.get('imageUrl')?.toString();
    const specialtyIds = formData.getAll('specialties').map(String);

    if (!id || !name) throw new Error('ID and Name are required');

    await prisma.doctor.update({
        where: { id },
        data: {
            name,
            title,
            bio,
            imageUrl,
            specialties: {
                set: specialtyIds.map(specId => ({ id: specId }))
            }
        }
    });

    revalidatePath('/admin/doctors');
    revalidatePath('/doctors');
    redirect('/admin/doctors');
}

export async function deleteDoctor(id: string) {
    await prisma.doctor.delete({
        where: { id }
    });

    revalidatePath('/admin/doctors');
    revalidatePath('/doctors');
}
