import { prisma } from '@/lib/prisma';
import { updateLeadStatus, updateLeadTags, deleteLead } from './actions';
import { Phone, Mail, Tag, Trash2, CalendarHeart, MessageSquare } from 'lucide-react';
import LeadStatusSelect from '@/components/admin/LeadStatusSelect';

export default async function AdminLeadsPage() {
    const leads = await prisma.lead.findMany({
        orderBy: { createdAt: 'desc' }
    });



    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <h1 className="heading-md">Lead Intelligence</h1>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                {leads.length === 0 ? (
                    <div className="glass-panel" style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-secondary)' }}>
                        No leads captured yet.
                    </div>
                ) : (
                    leads.map(lead => (
                        <div key={lead.id} className="glass-panel" style={{ padding: '1.5rem', borderRadius: 'var(--radius-lg)' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                                    <div style={{
                                        width: '40px', height: '40px', borderRadius: '50%',
                                        backgroundColor: lead.type === 'APPOINTMENT' ? 'var(--primary-color)' : 'var(--primary-light)',
                                        color: lead.type === 'APPOINTMENT' ? 'white' : 'var(--primary-dark)',
                                        display: 'flex', alignItems: 'center', justifyContent: 'center'
                                    }}>
                                        {lead.type === 'APPOINTMENT' ? <CalendarHeart size={20} /> : <MessageSquare size={20} />}
                                    </div>
                                    <div>
                                        <h3 style={{ fontSize: '1.1rem', fontWeight: 600 }}>{lead.name}</h3>
                                        <div style={{ display: 'flex', gap: '1rem', fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>
                                            <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}><Mail size={14} /> {lead.email}</span>
                                            {lead.phone && <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}><Phone size={14} /> {lead.phone}</span>}
                                        </div>
                                    </div>
                                </div>

                                <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                                    <form action={updateLeadStatus} style={{ display: 'flex', alignItems: 'center' }}>
                                        <input type="hidden" name="id" value={lead.id} />
                                        <LeadStatusSelect leadId={lead.id} currentStatus={lead.status} />
                                    </form>

                                    <form action={deleteLead}>
                                        <input type="hidden" name="id" value={lead.id} />
                                        <button type="submit" className="btn" style={{ padding: '0.4rem', backgroundColor: '#fee2e2', color: '#ef4444', border: '1px solid #fca5a5' }} title="Delete Lead">
                                            <Trash2 size={16} />
                                        </button>
                                    </form>
                                </div>
                            </div>

                            {lead.serviceRef && (
                                <div style={{ marginBottom: '1rem', fontSize: '0.85rem' }}>
                                    <span style={{ fontWeight: 600 }}>Requested Treatment:</span> {lead.serviceRef}
                                </div>
                            )}

                            {lead.message && (
                                <p style={{ color: 'var(--primary-dark)', lineHeight: 1.5, padding: '1rem', backgroundColor: 'rgba(255,255,255,0.5)', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', fontSize: '0.95rem' }}>
                                    {lead.message}
                                </p>
                            )}

                            <div style={{ marginTop: '1rem', borderTop: '1px solid var(--glass-border)', paddingTop: '1rem' }}>
                                <form action={updateLeadTags} style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                                    <input type="hidden" name="id" value={lead.id} />
                                    <Tag size={16} color="var(--text-secondary)" />
                                    <input
                                        type="text"
                                        name="tags"
                                        placeholder="Add comma-separated tags (e.g., Urgent, Referred, Follow-up)"
                                        defaultValue={lead.tags || ''}
                                        style={{ flex: 1, padding: '0.5rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', fontSize: '0.85rem' }}
                                    />
                                    <button type="submit" className="btn btn-outline" style={{ padding: '0.5rem', fontSize: '0.85rem' }}>Save Tags</button>
                                </form>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
}
