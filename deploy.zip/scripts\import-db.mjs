import { PrismaClient } from '@prisma/client';
import fs from 'fs';
import path from 'path';

// Note: Run this AFTER setting .env to the Supabase URL and running `npx prisma db push`

const prisma = new PrismaClient();

async function importData() {
    console.log("Importing data into Supabase PostgreSQL...");

    const inPath = path.join(process.cwd(), 'database_export.json');
    if (!fs.existsSync(inPath)) {
        throw new Error(`Export file not found at ${inPath}. Run export-db.mjs first.`);
    }

    const { doctors, specialties, pages, users } = JSON.parse(fs.readFileSync(inPath, 'utf8'));

    // Clear existing data (if any) to prevent conflicts, respecting foreign key constraints
    await prisma.doctor.deleteMany({});
    await prisma.specialty.deleteMany({});
    await prisma.pageContent.deleteMany({});
    await prisma.user.deleteMany({});

    console.log("Creating Users...");
    for (const user of users) {
        await prisma.user.create({ data: user });
    }

    console.log("Creating Specialties...");
    for (const spec of specialties) {
        await prisma.specialty.create({ data: spec });
    }

    console.log("Creating Doctors (and linking to specialties)...");
    for (const doc of doctors) {
        // Find existing specialties in the new DB that match the old doctor's specialties
        const specIds = doc.specialties ? doc.specialties.map(s => ({ id: s.id })) : [];

        // Remove the nested relation array before creating the doctor record
        delete doc.specialties;

        await prisma.doctor.create({
            data: {
                ...doc,
                specialties: {
                    connect: specIds
                }
            }
        });
    }

    console.log("Creating Pages...");
    for (const page of pages) {
        await prisma.pageContent.create({ data: page });
    }

    console.log("Migration complete!");
    await prisma.$disconnect();
}

importData().catch(console.error);
