import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

export const metadata = {
    title: 'Contact Us | Mind & Wellness',
}

export default async function ContactPage() {
    const pageData = await prisma.pageContent.findUnique({
        where: { slug: 'contact' }
    });

    async function submitMessage(formData: FormData) {
        'use server';
        const name = formData.get('name') as string;
        const email = formData.get('email') as string;
        const message = formData.get('message') as string;

        await prisma.lead.create({
            data: { name, email, message, type: 'CONTACT', status: 'NEW' }
        });

        revalidatePath('/contact');
    }

    return (
        <main className="section">
            <div className="container" style={{ textAlign: 'center', marginBottom: '4rem' }}>
                <h1 className="heading-lg">{pageData?.title || "Let's Talk About Your Journey"}</h1>
                {pageData?.content ? (
                    <div style={{ color: 'var(--text-secondary)', maxWidth: '600px', margin: '0 auto' }} dangerouslySetInnerHTML={{ __html: pageData.content }} />
                ) : (
                    <p style={{ color: 'var(--text-secondary)', maxWidth: '600px', margin: '0 auto' }}>
                        Reach out to our team of specialists today. Whether you need immediate assistance or wish to explore our rehabilitation programs, we are here to guide you.
                    </p>
                )}
            </div>

            <div className="container">
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '4rem' }}>
                    {/* Contact Info */}
                    <div>
                        <h2 className="heading-md" style={{ marginBottom: '2rem' }}>Get in Touch</h2>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                            <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                                <div style={{ padding: '1rem', backgroundColor: 'var(--primary-light)', borderRadius: '50%', color: 'var(--primary-dark)' }}>
                                    <MapPin size={24} />
                                </div>
                                <div>
                                    <h4 style={{ fontSize: '1.1rem', marginBottom: '0.25rem' }}>Location</h4>
                                    <p style={{ color: 'var(--text-secondary)' }}>123 Serenity Lane, Wellness District<br />New York, NY 10001</p>
                                </div>
                            </div>

                            <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                                <div style={{ padding: '1rem', backgroundColor: 'var(--primary-light)', borderRadius: '50%', color: 'var(--primary-dark)' }}>
                                    <Phone size={24} />
                                </div>
                                <div>
                                    <h4 style={{ fontSize: '1.1rem', marginBottom: '0.25rem' }}>Call Us</h4>
                                    <p style={{ color: 'var(--text-secondary)' }}>+1 (555) 123-4567<br />Mon - Fri, 9am - 6pm</p>
                                </div>
                            </div>

                            <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                                <div style={{ padding: '1rem', backgroundColor: 'var(--primary-light)', borderRadius: '50%', color: 'var(--primary-dark)' }}>
                                    <Mail size={24} />
                                </div>
                                <div>
                                    <h4 style={{ fontSize: '1.1rem', marginBottom: '0.25rem' }}>Email</h4>
                                    <p style={{ color: 'var(--text-secondary)' }}>support@sshimoh.com<br />inquiries@sshimoh.com</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Form */}
                    <div className="glass-panel" style={{ padding: '3rem', borderRadius: 'var(--radius-lg)' }}>
                        <h2 className="heading-md" style={{ marginBottom: '2rem' }}>Send us an Inquiry</h2>
                        <form action={submitMessage} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                <label htmlFor="name" style={{ fontWeight: 500 }}>Full Name</label>
                                <input type="text" id="name" name="name" required style={{ padding: '1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white' }} />
                            </div>

                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                <label htmlFor="email" style={{ fontWeight: 500 }}>Email Address</label>
                                <input type="email" id="email" name="email" required style={{ padding: '1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white' }} />
                            </div>

                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                <label htmlFor="message" style={{ fontWeight: 500 }}>How can we help you?</label>
                                <textarea id="message" name="message" required rows={5} style={{ padding: '1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white', fontFamily: 'inherit' }} />
                            </div>

                            <button type="submit" className="btn btn-primary" style={{ padding: '1rem' }}>
                                Submit Inquiry
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    );
}
