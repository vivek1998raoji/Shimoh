'use server';

import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { revalidatePath } from 'next/cache';

export async function updateUserPassword(formData: FormData) {
    const id = formData.get('id') as string;
    const newPassword = formData.get('newPassword') as string;

    if (!newPassword || newPassword.length < 6) {
        throw new Error('Password must be at least 6 characters');
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await prisma.user.update({
        where: { id },
        data: { password: hashedPassword }
    });

    revalidatePath('/admin/users');
}

export async function createAdminUser(formData: FormData) {
    const name = formData.get('name') as string;
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;

    if (!email || !password || password.length < 6) {
        throw new Error('Valid email and password (min 6 chars) are required');
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await prisma.user.create({
        data: {
            name,
            email,
            password: hashedPassword,
            role: 'ADMIN'
        }
    });

    revalidatePath('/admin/users');
}

export async function deleteUser(id: string) {
    const adminCount = await prisma.user.count({ where: { role: 'ADMIN' } });
    if (adminCount <= 1) {
        throw new Error('Cannot delete the last admin user.');
    }

    await prisma.user.delete({ where: { id } });
    revalidatePath('/admin/users');
}
