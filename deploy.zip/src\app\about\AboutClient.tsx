'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight, Sparkles, Heart, Shield, Users } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function AboutClient({ pageData }: { pageData: any }) {
    return (
        <>
            <Header />
            <main style={{ backgroundColor: 'var(--bg-color)', minHeight: '100vh', paddingBottom: '5rem' }}>
                {/* Hero Section */}
                <section style={{
                    position: 'relative',
                    padding: '12rem 0 6rem 0',
                    overflow: 'hidden',
                    background: 'linear-gradient(135deg, var(--bg-color) 0%, var(--primary-light) 100%)'
                }}>
                    <div style={{ position: 'absolute', top: '-10%', right: '-5%', width: '500px', height: '500px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(123, 153, 134, 0.2) 0%, rgba(255,255,255,0) 70%)', filter: 'blur(40px)', zIndex: 0 }} />
                    <div style={{ position: 'absolute', bottom: '-10%', left: '-5%', width: '400px', height: '400px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(230, 184, 156, 0.2) 0%, rgba(255,255,255,0) 70%)', filter: 'blur(40px)', zIndex: 0 }} />

                    <div className="container" style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
                        <motion.div
                            initial={{ opacity: 0, y: 30 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.8, ease: "easeOut" }}
                        >
                            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 1.25rem', backgroundColor: 'rgba(255,255,255,0.6)', backdropFilter: 'blur(10px)', borderRadius: '2rem', border: '1px solid var(--glass-border)', color: 'var(--primary-dark)', fontWeight: 500, marginBottom: '1.5rem' }}>
                                <Sparkles size={16} fill="var(--primary-dark)" />
                                <span>Discover SSHIMOH</span>
                            </div>
                            <h1 className="heading-xl" style={{ fontSize: 'clamp(3rem, 6vw, 4.5rem)', maxWidth: '900px', margin: '0 auto 1.5rem', lineHeight: 1.1 }}>
                                {pageData?.title || "Healing Through Compassion & Precision"}
                            </h1>
                            <p style={{ fontSize: '1.25rem', color: 'var(--text-secondary)', maxWidth: '650px', margin: '0 auto', lineHeight: 1.6 }}>
                                We are dedicated to pioneering mental wellness and transformative care in a serene, holistic environment designed exclusively for your recovery.
                            </p>
                        </motion.div>
                    </div>
                </section>

                {/* Content Section */}
                <section className="section" style={{ position: 'relative', zIndex: 10, marginTop: '-2rem' }}>
                    <div className="container" style={{ maxWidth: '900px' }}>
                        <motion.div
                            className="glass-panel"
                            style={{ padding: '4rem', borderRadius: 'var(--radius-lg)' }}
                            initial={{ opacity: 0, y: 40 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.6 }}
                        >
                            {pageData?.content ? (
                                <div className="cms-content" dangerouslySetInnerHTML={{ __html: pageData.content }} style={{ lineHeight: 1.9, fontSize: '1.1rem', color: 'var(--text-primary)' }} />
                            ) : (
                                <div style={{ lineHeight: 1.9, fontSize: '1.1rem', color: 'var(--text-primary)' }}>
                                    <h2 className="heading-md" style={{ color: 'var(--primary-dark)' }}>Our Mission</h2>
                                    <p style={{ marginBottom: '2.5rem' }}>
                                        At SSHIMOH, our mission is to provide compassionate, evidence-based mental healthcare that empowers individuals to reclaim their lives. We believe in holistic healing, treating the mind, body, and spirit in a serene, supportive environment away from the chaos of everyday life.
                                    </p>

                                    <h2 className="heading-md" style={{ color: 'var(--primary-dark)' }}>Our Vision</h2>
                                    <p style={{ marginBottom: '2.5rem' }}>
                                        To be the global sanctuary for mental wellness, where clinical excellence meets empathetic, personalized attention.
                                    </p>

                                    <h2 className="heading-md" style={{ color: 'var(--primary-dark)' }}>Our Approach</h2>
                                    <p>
                                        We utilize a multi-disciplinary approach, combining advanced psychiatric care with therapeutic modalities tailored to each individual's unique journey. Our team of world-class professionals is dedicated to walking alongside you every step of the way, fostering a foundation of lifelong resilience.
                                    </p>
                                </div>
                            )}
                        </motion.div>
                    </div>
                </section>

                {/* Values Grid */}
                <section className="section">
                    <div className="container">
                        <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
                            <h2 className="heading-lg">Our Core Values</h2>
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem' }}>
                            <motion.div
                                className="glass-panel"
                                style={{ padding: '2.5rem', textAlign: 'center', borderRadius: 'var(--radius-md)' }}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.5, delay: 0.1 }}
                            >
                                <Heart size={40} color="var(--accent-color)" style={{ margin: '0 auto 1.5rem' }} />
                                <h3 style={{ fontSize: '1.3rem', marginBottom: '1rem' }}>Empathy First</h3>
                                <p style={{ color: 'var(--text-secondary)' }}>We listen without judgment, creating a safe harbor for the most vulnerable thoughts.</p>
                            </motion.div>

                            <motion.div
                                className="glass-panel"
                                style={{ padding: '2.5rem', textAlign: 'center', borderRadius: 'var(--radius-md)' }}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.5, delay: 0.2 }}
                            >
                                <Shield size={40} color="var(--primary-dark)" style={{ margin: '0 auto 1.5rem' }} />
                                <h3 style={{ fontSize: '1.3rem', marginBottom: '1rem' }}>Clinical Excellence</h3>
                                <p style={{ color: 'var(--text-secondary)' }}>Our therapies are rooted in the latest scientific research and psychiatric advancements.</p>
                            </motion.div>

                            <motion.div
                                className="glass-panel"
                                style={{ padding: '2.5rem', textAlign: 'center', borderRadius: 'var(--radius-md)' }}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.5, delay: 0.3 }}
                            >
                                <Users size={40} color="var(--primary-color)" style={{ margin: '0 auto 1.5rem' }} />
                                <h3 style={{ fontSize: '1.3rem', marginBottom: '1rem' }}>Holistic Connection</h3>
                                <p style={{ color: 'var(--text-secondary)' }}>Healing the individual by restoring their connection to themselves, their families, and society.</p>
                            </motion.div>
                        </div>
                    </div>
                </section>

                {/* Call to Action */}
                <section className="section">
                    <div className="container">
                        <motion.div
                            style={{
                                backgroundColor: 'var(--primary-dark)',
                                color: 'white',
                                padding: '4rem',
                                borderRadius: 'var(--radius-lg)',
                                textAlign: 'center',
                                position: 'relative',
                                overflow: 'hidden'
                            }}
                            initial={{ opacity: 0, scale: 0.95 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.6 }}
                        >
                            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, background: 'radial-gradient(circle at center, rgba(255,255,255,0.1) 0%, transparent 60%)' }} />
                            <h2 className="heading-lg" style={{ color: 'white', position: 'relative', zIndex: 1 }}>Ready to Meet the Team?</h2>
                            <p style={{ color: 'var(--primary-light)', fontSize: '1.2rem', maxWidth: '600px', margin: '0 auto 2.5rem', position: 'relative', zIndex: 1 }}>
                                Discover the specialized doctors and clinical therapists defining the SSHIMOH standard of care.
                            </p>
                            <Link href="/doctors" className="btn btn-outline" style={{ position: 'relative', zIndex: 1, backgroundColor: 'transparent', color: 'white', borderColor: 'rgba(255,255,255,0.4)', padding: '1rem 2.5rem', fontSize: '1.1rem' }}>
                                View Clinical Team <ArrowRight size={18} style={{ display: 'inline', marginLeft: '0.5rem' }} />
                            </Link>
                        </motion.div>
                    </div>
                </section>
            </main>
            <Footer />
        </>
    );
}
