import { createPage } from '../actions';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import ImageUploader from '@/components/admin/ImageUploader';

export default function NewPageContent() {
    return (
        <div>
            <div style={{ marginBottom: '2rem' }}>
                <Link href="/admin/content" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-secondary)', marginBottom: '1rem' }}>
                    <ArrowLeft size={16} /> Back to Pages
                </Link>
                <h1 className="heading-md">Create New Page Content</h1>
            </div>

            <div className="glass-panel" style={{ padding: '2rem', borderRadius: 'var(--radius-lg)' }}>
                <form action={createPage} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            <label htmlFor="title" style={{ fontWeight: 500 }}>Page Title</label>
                            <input
                                type="text"
                                id="title"
                                name="title"
                                required
                                style={{ padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white' }}
                            />
                        </div>

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            <label htmlFor="slug" style={{ fontWeight: 500 }}>URL Slug</label>
                            <input
                                type="text"
                                id="slug"
                                name="slug"
                                placeholder="e.g. privacy-policy"
                                required
                                style={{ padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white' }}
                            />
                        </div>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <label htmlFor="content" style={{ fontWeight: 500 }}>Page Content (Supports HTML and Markdown Data)</label>
                            <ImageUploader onUploadSuccess={(url) => {
                                alert(`Image uploaded! URL: ${url}\nYou can copy and paste this URL into your content.`);
                                console.log('Uploaded URL:', url);
                            }} />
                        </div>
                        <textarea
                            id="content"
                            name="content"
                            rows={15}
                            required
                            style={{ padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white', fontFamily: 'monospace' }}
                        />
                    </div>

                    <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
                        Note: For hardcoded aesthetic pages like Home or About, using the identical slug will allow dynamic overriding if you modify the frontend to fetch it.
                    </p>

                    <button type="submit" className="btn btn-primary" style={{ marginTop: '1rem', alignSelf: 'flex-start' }}>
                        Publish Page
                    </button>
                </form>
            </div>
        </div>
    );
}
