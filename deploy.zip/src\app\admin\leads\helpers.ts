export const getStatusColor = (status: string) => {
    switch (status) {
        case 'NEW': return { bg: '#dbeafe', color: '#1e40af' };
        case 'CONTACTED': return { bg: '#fef3c7', color: '#b45309' };
        case 'CONVERTED': return { bg: '#dcfce7', color: '#166534' };
        case 'LOST': return { bg: '#fee2e2', color: '#991b1b' };
        default: return { bg: '#f3f4f6', color: '#374151' };
    }
}
