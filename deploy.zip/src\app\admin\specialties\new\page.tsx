'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Save } from 'lucide-react';
import ImageUploader from '@/components/admin/ImageUploader';
import { createSpecialty } from '../actions';

export default function NewSpecialtyPage() {
    const router = useRouter();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [imageUrl, setImageUrl] = useState('');

    async function handleSubmit(formData: FormData) {
        setIsSubmitting(true);
        if (imageUrl) {
            formData.append('imageUrl', imageUrl);
        }

        // Auto-generate slug if not provided
        let slug = formData.get('slug') as string;
        if (!slug) {
            const name = formData.get('name') as string;
            slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
            formData.set('slug', slug);
        }

        await createSpecialty(formData);
        router.push('/admin/specialties');
    }

    return (
        <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
                <Link href="/admin/specialties" style={{ color: 'var(--text-secondary)' }}>
                    <ArrowLeft size={20} />
                </Link>
                <h1 className="heading-md" style={{ margin: 0 }}>Create Treatment</h1>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>
                <div className="glass-panel" style={{ padding: '2rem', borderRadius: 'var(--radius-lg)' }}>
                    <form action={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            <label htmlFor="name" style={{ fontWeight: 500 }}>Treatment Name *</label>
                            <input type="text" id="name" name="name" required style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white' }} placeholder="e.g. Women's Mental Health" />
                        </div>

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            <label htmlFor="slug" style={{ fontWeight: 500 }}>URL Slug (Optional)</label>
                            <input type="text" id="slug" name="slug" style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white' }} placeholder="e.g. womens-mental-health (auto-generated if empty)" />
                        </div>

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            <label htmlFor="description" style={{ fontWeight: 500 }}>Short Description</label>
                            <textarea id="description" name="description" rows={3} style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white', fontFamily: 'inherit' }} placeholder="Brief overview for the homepage card..." />
                        </div>

                        <input type="hidden" name="imageUrl" value={imageUrl} />

                        <div style={{ marginTop: '1rem', display: 'flex', justifyContent: 'flex-end', gap: '1rem' }}>
                            <Link href="/admin/specialties" className="btn btn-outline" style={{ padding: '0.75rem 1.5rem' }}>
                                Cancel
                            </Link>
                            <button type="submit" disabled={isSubmitting} className="btn btn-primary" style={{ padding: '0.75rem 1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                {isSubmitting ? 'Saving...' : <><Save size={18} /> Save Treatment</>}
                            </button>
                        </div>
                    </form>
                </div>

                <div className="glass-panel" style={{ padding: '2rem', borderRadius: 'var(--radius-lg)', height: 'fit-content' }}>
                    <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>Featured Image</h3>
                    <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '1.5rem' }}>
                        Upload an image to display on the Homepage card.
                    </p>

                    {imageUrl ? (
                        <div style={{ marginBottom: '1rem', border: '1px solid var(--glass-border)', borderRadius: 'var(--radius-md)', overflow: 'hidden' }}>
                            <img src={imageUrl} alt="Preview" style={{ width: '100%', height: '200px', objectFit: 'cover' }} />
                            <button onClick={() => setImageUrl('')} className="btn btn-outline" style={{ width: '100%', borderRadius: 0, border: 'none', borderTop: '1px solid var(--glass-border)' }}>
                                Remove Image
                            </button>
                        </div>
                    ) : (
                        <ImageUploader onUploadSuccess={(url) => setImageUrl(url)} />
                    )}
                </div>
            </div>
        </div>
    );
}
