import Link from 'next/link';
import styles from './Footer.module.css';

export default function Footer() {
    return (
        <footer className={styles.footer}>
            <div className={`container ${styles.footerGrid}`}>
                <div className={styles.brandCol}>
                    <h3>Mind <span>&</span> Wellness</h3>
                    <p>Guided paths to inner peace and holistic rejuvenation. Find your balance.</p>
                </div>

                <div className={styles.linksCol}>
                    <h4>Company</h4>
                    <Link href="/about">About Us</Link>
                    <Link href="/doctors">Our Team</Link>
                    <Link href="/specialties">Specialties</Link>
                    <Link href="/contact">Contact</Link>
                </div>

                <div className={styles.linksCol}>
                    <h4>Legal</h4>
                    <Link href="#">Privacy Policy</Link>
                    <Link href="#">Terms of Service</Link>
                </div>
            </div>
            <div className={styles.copyright}>
                <p>&copy; {new Date().getFullYear()} Mind & Wellness Organization. All rights reserved.</p>
                <Link href="/admin">Admin Login</Link>
            </div>
        </footer>
    );
}
