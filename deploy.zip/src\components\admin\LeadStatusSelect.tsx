'use client';

import { getStatusColor } from '@/app/admin/leads/helpers';

export default function LeadStatusSelect({ leadId, currentStatus }: { leadId: string, currentStatus: string }) {
    return (
        <select
            name="status"
            defaultValue={currentStatus}
            onChange={(e) => e.target.form?.requestSubmit()}
            style={{
                padding: '0.4rem 0.8rem', borderRadius: '1rem', border: 'none', fontWeight: 600, fontSize: '0.75rem', cursor: 'pointer',
                backgroundColor: getStatusColor(currentStatus).bg, color: getStatusColor(currentStatus).color
            }}
        >
            <option value="NEW">NEW LEAD</option>
            <option value="CONTACTED">CONTACTED</option>
            <option value="CONVERTED">CONVERTED</option>
            <option value="LOST">LOST</option>
        </select>
    );
}
