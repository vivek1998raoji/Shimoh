import { prisma } from '@/lib/prisma';
import HomeClient from './HomeClient';

export default async function Home() {
  // Fetch dynamic content
  const pageData = await prisma.pageContent.findUnique({
    where: { slug: 'home' }
  });

  let contentJson = null;

  if (pageData && pageData.content) {
    try {
      contentJson = JSON.parse(pageData.content);
    } catch (e) {
      console.error("Failed to parse home JSON from DB", e);
    }
  }

  const specialties = await prisma.specialty.findMany({
    orderBy: { name: 'asc' },
  });

  return <HomeClient contentData={contentJson} specialtiesData={specialties} />;
}
