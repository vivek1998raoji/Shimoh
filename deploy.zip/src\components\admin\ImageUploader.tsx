'use client';

import { useState } from 'react';
import { UploadCloud, Loader2, Image as ImageIcon } from 'lucide-react';

export default function ImageUploader({ onUploadSuccess }: { onUploadSuccess: (url: string) => void }) {
    const [uploading, setUploading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setUploading(true);
        setError(null);

        const formData = new FormData();
        formData.append('file', file);

        try {
            const res = await fetch('/api/upload', {
                method: 'POST',
                body: formData,
            });
            const data = await res.json();

            if (data.success) {
                onUploadSuccess(data.url);
            } else {
                setError(data.error || 'Upload failed');
            }
        } catch (err: any) {
            setError(err.message || 'Network error');
        } finally {
            setUploading(false);
            // Reset input so the same file could be selected again if needed
            e.target.value = '';
        }
    };

    return (
        <div style={{ display: 'inline-block' }}>
            <label style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                padding: '0.5rem 1rem',
                backgroundColor: 'var(--bg-color)',
                border: '1px dashed var(--primary-dark)',
                borderRadius: 'var(--radius-md)',
                cursor: 'pointer',
                color: 'var(--primary-dark)',
                fontSize: '0.85rem',
                fontWeight: 500,
                transition: 'all 0.2s',
                opacity: uploading ? 0.7 : 1
            }}>
                {uploading ? <Loader2 size={16} className="spin" /> : <UploadCloud size={16} />}
                {uploading ? 'Uploading...' : 'Upload Image'}
                <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    disabled={uploading}
                    style={{ display: 'none' }}
                />
            </label>
            {error && <span style={{ color: 'red', fontSize: '0.75rem', marginLeft: '0.5rem' }}>{error}</span>}
        </div>
    );
}
