import styles from './admin.module.css';
import { prisma } from '@/lib/prisma';
import { Users, FileText, MessageSquare } from 'lucide-react';

export default async function AdminDashboard() {
    const [doctorCount, pageCount, unreadMessages] = await Promise.all([
        prisma.doctor.count(),
        prisma.pageContent.count(),
        prisma.lead.count({ where: { status: 'NEW' } })
    ]);

    return (
        <div>
            <h1 className="heading-md">Overview</h1>
            <p className={styles.subtitle}>Here is what is happening with your wellness organization today.</p>

            <div className={styles.statsGrid}>
                <div className={styles.statCard}>
                    <div className={styles.statIcon} style={{ backgroundColor: 'rgba(123, 153, 134, 0.1)' }}>
                        <FileText color="var(--primary-dark)" />
                    </div>
                    <div>
                        <h3>{pageCount}</h3>
                        <p>Published Pages</p>
                    </div>
                </div>

                <div className={styles.statCard}>
                    <div className={styles.statIcon} style={{ backgroundColor: 'rgba(230, 184, 156, 0.2)' }}>
                        <Users color="var(--accent-color)" />
                    </div>
                    <div>
                        <h3>{doctorCount}</h3>
                        <p>Team Members</p>
                    </div>
                </div>

                <div className={styles.statCard}>
                    <div className={styles.statIcon} style={{ backgroundColor: 'rgba(45, 55, 72, 0.1)' }}>
                        <MessageSquare color="var(--text-primary)" />
                    </div>
                    <div>
                        <h3>{unreadMessages}</h3>
                        <p>Unread Messages</p>
                    </div>
                </div>
            </div>
        </div>
    );
}
