import styles from './login.module.css';
import LoginForm from './LoginForm';

export const metadata = {
    title: 'Admin Login | Mind & Wellness',
}

export default function LoginPage() {
    return (
        <main className={styles.loginContainer}>
            <div className={styles.loginCard + ' glass-panel'}>
                <div className={styles.logo}>
                    <h2>Mind & Wellness</h2>
                    <p>Administrative Portal</p>
                </div>

                <LoginForm />

                <div className={styles.footer}>
                    <p>Secure Access Only</p>
                </div>
            </div>
        </main>
    );
}
