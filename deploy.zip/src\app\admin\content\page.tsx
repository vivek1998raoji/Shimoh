import { prisma } from '@/lib/prisma';
import Link from 'next/link';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { revalidatePath } from 'next/cache';

export default async function AdminContentPage() {
    const pages = await prisma.pageContent.findMany({
        orderBy: { createdAt: 'desc' },
    });

    async function deletePage(formData: FormData) {
        'use server';
        const id = formData.get('id') as string;
        await prisma.pageContent.delete({ where: { id } });
        revalidatePath('/admin/content');
    }

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <h1 className="heading-md">Page Content Management</h1>
                <Link href="/admin/content/new" className="btn btn-primary" style={{ padding: '0.5rem 1rem', display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                    <Plus size={18} /> New Page
                </Link>
            </div>

            <div className="glass-panel" style={{ padding: '2rem', borderRadius: 'var(--radius-lg)' }}>
                {pages.length === 0 ? (
                    <p style={{ color: 'var(--text-secondary)' }}>No pages found. Create one to get started.</p>
                ) : (
                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead>
                            <tr style={{ borderBottom: '1px solid var(--glass-border)' }}>
                                <th style={{ padding: '1rem', color: 'var(--text-secondary)' }}>Title</th>
                                <th style={{ padding: '1rem', color: 'var(--text-secondary)' }}>Slug</th>
                                <th style={{ padding: '1rem', color: 'var(--text-secondary)' }}>Status</th>
                                <th style={{ padding: '1rem', textAlign: 'right', color: 'var(--text-secondary)' }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {pages.map(page => (
                                <tr key={page.id} style={{ borderBottom: '1px solid var(--glass-border)' }}>
                                    <td style={{ padding: '1rem', fontWeight: 500 }}>{page.title}</td>
                                    <td style={{ padding: '1rem', color: 'var(--text-secondary)' }}>/{page.slug}</td>
                                    <td style={{ padding: '1rem' }}>
                                        <span style={{
                                            padding: '0.25rem 0.5rem',
                                            borderRadius: '1rem',
                                            fontSize: '0.75rem',
                                            fontWeight: 600,
                                            backgroundColor: 'var(--primary-light)',
                                            color: 'var(--primary-dark)'
                                        }}>
                                            Published
                                        </span>
                                    </td>
                                    <td style={{ padding: '1rem', textAlign: 'right' }}>
                                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
                                            <Link href={`/admin/content/${page.id}`} className="btn btn-outline" style={{ padding: '0.5rem' }}>
                                                <Edit size={16} />
                                            </Link>
                                            <form action={deletePage}>
                                                <input type="hidden" name="id" value={page.id} />
                                                <button type="submit" className="btn" style={{ padding: '0.5rem', backgroundColor: '#fee2e2', color: '#ef4444', border: '1px solid #fca5a5' }}>
                                                    <Trash2 size={16} />
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
}
