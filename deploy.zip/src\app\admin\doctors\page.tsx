import { prisma } from '@/lib/prisma';
import Link from 'next/link';
import styles from '../admin.module.css';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { deleteDoctor } from './actions';

export default async function DoctorsPage() {
    const doctors = await prisma.doctor.findMany({
        orderBy: { createdAt: 'desc' }
    });

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <div>
                    <h1 className="heading-md">Team Management</h1>
                    <p className={styles.subtitle}>Manage your organization's wellness professionals.</p>
                </div>
                <Link href="/admin/doctors/new" className="btn btn-primary">
                    <Plus size={18} style={{ marginRight: '0.5rem' }} /> Add Doctor
                </Link>
            </div>

            <div className="glass-panel" style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                    <thead>
                        <tr style={{ borderBottom: '1px solid var(--glass-border)', backgroundColor: 'rgba(255,255,255,0.5)' }}>
                            <th style={{ padding: '1rem 1.5rem', fontWeight: 500 }}>Name</th>
                            <th style={{ padding: '1rem 1.5rem', fontWeight: 500 }}>Title</th>
                            <th style={{ padding: '1rem 1.5rem', fontWeight: 500, textAlign: 'right' }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {doctors.length === 0 ? (
                            <tr>
                                <td colSpan={3} style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-secondary)' }}>
                                    No doctors found. Add one to get started.
                                </td>
                            </tr>
                        ) : (
                            doctors.map((doc) => (
                                <tr key={doc.id} style={{ borderBottom: '1px solid var(--glass-border)' }}>
                                    <td style={{ padding: '1rem 1.5rem', fontWeight: 500 }}>{doc.name}</td>
                                    <td style={{ padding: '1rem 1.5rem', color: 'var(--text-secondary)' }}>{doc.title || '-'}</td>
                                    <td style={{ padding: '1rem 1.5rem', textAlign: 'right', display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
                                        <Link href={`/admin/doctors/${doc.id}`} className="btn btn-outline" style={{ padding: '0.5rem', color: 'var(--primary-dark)', borderColor: 'var(--glass-border)' }}>
                                            <Edit size={18} />
                                        </Link>
                                        <form action={async () => {
                                            'use server';
                                            await deleteDoctor(doc.id);
                                        }}>
                                            <button type="submit" className="btn btn-outline" style={{ padding: '0.5rem', color: '#dc3545', borderColor: 'transparent' }}>
                                                <Trash2 size={18} />
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
