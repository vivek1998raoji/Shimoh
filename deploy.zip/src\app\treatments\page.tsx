import { prisma } from '@/lib/prisma';
import Link from 'next/link';
import { ArrowRight, Activity } from 'lucide-react';
import { notFound } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default async function TreatmentsPage() {
    const treatments = await prisma.specialty.findMany({
        orderBy: { name: 'asc' }
    });

    if (!treatments || treatments.length === 0) {
        return (
            <main style={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <p>No treatments found. We are updating our catalog.</p>
            </main>
        );
    }

    return (
        <>
            <Header />
            <main style={{ backgroundColor: 'var(--bg-color)', minHeight: '100vh', padding: '8rem 0 5rem 0' }}>
                <div className="container">
                    <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
                        <h1 className="heading-xl">Our Core Services</h1>
                        <p style={{ color: 'var(--text-secondary)', maxWidth: '600px', margin: '1rem auto' }}>
                            Explore our comprehensive list of specialized treatments designed to foster healing and lasting hope.
                        </p>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '2rem' }}>
                        {treatments.map((t, idx) => (
                            <div
                                key={t.id}
                                className="glass-panel"
                                style={{
                                    padding: '2.5rem',
                                    borderRadius: 'var(--radius-lg)',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                                    position: 'relative',
                                    overflow: 'hidden',
                                    cursor: 'pointer'
                                }}
                            >
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem' }}>
                                    <div style={{ margin: 0, width: '60px', height: '60px', overflow: 'hidden', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--primary-light)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                        {t.imageUrl ? (
                                            <img src={t.imageUrl} alt={t.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                        ) : (
                                            <Activity color="var(--primary-dark)" size={28} />
                                        )}
                                    </div>
                                    <ArrowRight size={24} color="var(--primary-color)" />
                                </div>
                                <h3 style={{ fontSize: '1.25rem', marginBottom: '0.75rem', fontWeight: 600 }}>{t.name}</h3>
                                <p style={{ color: 'var(--text-secondary)', lineHeight: 1.6, flexGrow: 1, minHeight: '80px' }}>
                                    {t.description}
                                </p>
                                <Link
                                    href={`/treatments/${t.slug}`}
                                    className="btn btn-outline"
                                    style={{ marginTop: '2rem', width: '100%', textAlign: 'center' }}
                                >
                                    Learn More
                                </Link>
                            </div>
                        ))}
                    </div>
                </div>
            </main>
            <Footer />
        </>
    );
}
