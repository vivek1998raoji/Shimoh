import axios from 'axios';
import * as cheerio from 'cheerio';
import { PrismaClient } from '@prisma/client';
import fs from 'fs';
import path from 'path';

const prisma = new PrismaClient();

function slugify(text) {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
}

async function downloadImage(url, slug) {
    const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
    if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
    }

    // Get extension
    const extMatch = url.match(/\.(png|jpg|jpeg|webp)/i);
    const ext = extMatch ? extMatch[0] : '.png';
    const filename = `${slug}${ext}`;
    const filepath = path.join(uploadsDir, filename);

    try {
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'stream'
        });

        const writer = fs.createWriteStream(filepath);
        response.data.pipe(writer);

        return new Promise((resolve, reject) => {
            writer.on('finish', () => resolve(`/uploads/${filename}`));
            writer.on('error', reject);
        });
    } catch (err) {
        console.error(`Failed to download image ${url}`, err);
        return null;
    }
}

async function scrapeTreatments() {
    try {
        console.log('Fetching reference site...');
        const url = 'https://gray-beaver-196381.hostingersite.com/';
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);

        // Target the specific section that holds the treatments.
        // They are typically in elementor containers that have h2 elements.
        const treatments = [];

        $('h2.elementor-heading-title').each((i, el) => {
            const text = $(el).text().trim().replace(/\n/g, ' ');
            // Filter out non-treatment headings based on known headings
            if (text && text.length > 5 && text.includes('Mental Health') || text.includes('Disorders') || text.includes('Addiction')) {
                const container = $(el).closest('.e-con');
                if (container.length) {
                    const desc = container.find('.elementor-widget-text-editor').text().trim();
                    const imgSrc = container.find('.elementor-widget-image img').attr('src');

                    // Clean up name
                    const cleanName = text.replace(/\n/g, ' ').replace(/\s+/g, ' ');

                    treatments.push({
                        name: cleanName,
                        slug: slugify(cleanName),
                        description: desc || 'Comprehensive and specialized care tailored for your recovery.',
                        originalImg: imgSrc
                    });
                }
            }
        });

        console.log(`Found ${treatments.length} treatments to insert.`);

        for (const t of treatments) {
            let localImgUrl = null;
            if (t.originalImg) {
                console.log(`Downloading image for ${t.name}...`);
                localImgUrl = await downloadImage(t.originalImg, t.slug);
            }

            console.log(`Upserting ${t.name} to database...`);
            await prisma.specialty.upsert({
                where: { slug: t.slug },
                update: {
                    name: t.name,
                    description: t.description,
                    imageUrl: localImgUrl
                },
                create: {
                    name: t.name,
                    slug: t.slug,
                    description: t.description,
                    imageUrl: localImgUrl
                }
            });
        }

        console.log("Scraping and seeding complete!");

    } catch (error) {
        console.error('Scraping error:', error);
    } finally {
        await prisma.$disconnect();
    }
}

scrapeTreatments();
