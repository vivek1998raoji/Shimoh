'use server';

import { prisma } from '@/lib/prisma';

export async function submitBookingLead(formData: FormData) {
    const name = formData.get('name') as string;
    const email = formData.get('email') as string;
    const phone = formData.get('phone') as string;
    const serviceRef = formData.get('service') as string;

    await prisma.lead.create({
        data: {
            name,
            email,
            phone,
            serviceRef,
            type: 'APPOINTMENT',
            status: 'NEW'
        }
    });
}
