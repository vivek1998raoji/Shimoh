'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

export async function updateLeadStatus(formData: FormData) {
    const id = formData.get('id') as string;
    const status = formData.get('status') as string;

    await prisma.lead.update({
        where: { id },
        data: { status }
    });

    revalidatePath('/admin/leads');
}

export async function updateLeadTags(formData: FormData) {
    const id = formData.get('id') as string;
    const tags = formData.get('tags') as string; // Comma separated string

    await prisma.lead.update({
        where: { id },
        data: { tags }
    });

    revalidatePath('/admin/leads');
}

export async function deleteLead(formData: FormData) {
    const id = formData.get('id') as string;

    await prisma.lead.delete({
        where: { id }
    });

    revalidatePath('/admin/leads');
}
