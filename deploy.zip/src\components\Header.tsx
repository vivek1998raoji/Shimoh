'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import styles from './Header.module.css';

export default function Header() {
    const pathname = usePathname();
    const [scrolled, setScrolled] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    if (pathname.startsWith('/admin') || pathname === '/login') {
        return null;
    }

    return (
        <>
            <motion.header
                className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}
                initial={{ y: -100 }}
                animate={{ y: 0 }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
            >
                <div className={`container ${styles.headerContent}`}>
                    <Link href="/" className={styles.logo}>
                        Mind <span>&</span> Wellness
                    </Link>

                    <nav className={styles.nav}>
                        <Link href="/" className={pathname === '/' ? styles.active : ''}>Home</Link>
                        <Link href="/about" className={pathname === '/about' ? styles.active : ''}>About Us</Link>
                        <Link href="/treatments" className={pathname.includes('/treatments') ? styles.active : ''}>Treatments</Link>
                        <Link href="/doctors" className={pathname === '/doctors' ? styles.active : ''}>Our Team</Link>
                    </nav>

                    <button onClick={() => setIsModalOpen(true)} className="btn btn-primary" style={{ padding: '0.6rem 1.5rem' }}>
                        Book Appointment
                    </button>
                </div>
            </motion.header>

            {isModalOpen && (
                <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(4px)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="glass-panel"
                        style={{ padding: '3rem', borderRadius: 'var(--radius-lg)', width: '100%', maxWidth: '500px', backgroundColor: 'white', position: 'relative' }}
                    >
                        <button onClick={() => setIsModalOpen(false)} style={{ position: 'absolute', top: '1.5rem', right: '1.5rem', background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer' }}>&times;</button>
                        <h2 className="heading-sm" style={{ marginBottom: '1rem' }}>Request an Appointment</h2>
                        <p style={{ color: 'var(--text-secondary)', marginBottom: '2rem' }}>Fill out your details and our care team will contact you securely.</p>

                        <form action={async (formData) => {
                            try {
                                const { submitBookingLead } = await import('@/app/actions/booking');
                                await submitBookingLead(formData);
                                alert('Appointment requested successfully! Our team will contact you shortly.');
                                setIsModalOpen(false);
                            } catch (e) {
                                console.error("Lead submission failed:", e);
                                alert('Failed to submit request. Please try again or call us.');
                            }
                        }} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            <input type="text" name="name" placeholder="Full Name" required style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)' }} />
                            <input type="email" name="email" placeholder="Email Address" required style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)' }} />
                            <input type="tel" name="phone" placeholder="Phone Number" required style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)' }} />
                            <select name="service" style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', backgroundColor: 'white' }}>
                                <option value="General">Consultation (General)</option>
                                <option value="Women's Mental Health">Women's Mental Health</option>
                                <option value="Men's Mental Health">Men's Mental Health</option>
                                <option value="De-Addiction">De-Addiction</option>
                            </select>
                            <button type="submit" className="btn btn-primary" style={{ marginTop: '1rem' }}>Submit Request</button>
                        </form>
                    </motion.div>
                </div>
            )}
        </>
    );
}
