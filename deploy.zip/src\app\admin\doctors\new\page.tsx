import { createDoctor } from '../actions';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { prisma } from '@/lib/prisma';

export default async function NewDoctorPage() {
    const specialties = await prisma.specialty.findMany({ orderBy: { name: 'asc' } });

    return (
        <div>
            <div style={{ marginBottom: '2rem' }}>
                <Link href="/admin/doctors" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-secondary)', marginBottom: '1rem' }}>
                    <ArrowLeft size={16} /> Back to Doctors
                </Link>
                <h1 className="heading-md">Add New Team Member</h1>
            </div>

            <div className="glass-panel" style={{ padding: '2rem', borderRadius: 'var(--radius-lg)', maxWidth: '600px' }}>
                <form action={createDoctor} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        <label htmlFor="name" style={{ fontWeight: 500 }}>Full Name</label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            required
                            style={{ padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white' }}
                        />
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        <label htmlFor="title" style={{ fontWeight: 500 }}>Designation / Professional Title</label>
                        <input
                            type="text"
                            id="title"
                            name="title"
                            placeholder="e.g. Clinical Psychologist"
                            style={{ padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white' }}
                        />
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        <label htmlFor="imageUrl" style={{ fontWeight: 500 }}>Profile Image URL</label>
                        <input
                            type="url"
                            id="imageUrl"
                            name="imageUrl"
                            placeholder="https://example.com/photo.jpg"
                            style={{ padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white' }}
                        />
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        <label style={{ fontWeight: 500 }}>Specialties</label>
                        {specialties.length === 0 ? (
                            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>No specialties created yet. Go to Specialties page to add them.</p>
                        ) : (
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                                {specialties.map(spec => (
                                    <label key={spec.id} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.9rem' }}>
                                        <input type="checkbox" name="specialties" value={spec.id} />
                                        {spec.name}
                                    </label>
                                ))}
                            </div>
                        )}
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        <label htmlFor="bio" style={{ fontWeight: 500 }}>Biography</label>
                        <textarea
                            id="bio"
                            name="bio"
                            rows={5}
                            style={{ padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', background: 'white', fontFamily: 'inherit' }}
                        />
                    </div>

                    <button type="submit" className="btn btn-primary" style={{ marginTop: '1rem' }}>
                        Save Profile
                    </button>
                </form>
            </div>
        </div>
    );
}
