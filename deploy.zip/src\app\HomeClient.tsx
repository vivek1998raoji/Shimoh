'use client';

import { motion } from 'framer-motion';
import styles from './home.module.css';
import Link from 'next/link';
import { ArrowRight, Star, Heart, Activity, CheckCircle2 } from 'lucide-react';

export default function HomeClient({ contentData, specialtiesData }: { contentData: any, specialtiesData?: any[] }) {
    if (!contentData) return <div>Loading...</div>;

    return (
        <main>
            {/* 1. Hero Section */}
            <section className={styles.heroSection} style={contentData.hero?.bgImage ? { backgroundImage: `url(${contentData.hero.bgImage})`, backgroundSize: 'cover' } : {}}>
                <div className={`container ${styles.heroContainer}`} style={{ textAlign: 'center' }}>
                    <motion.div
                        className={styles.heroContent}
                        style={{ margin: '0 auto' }}
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                    >
                        <h1 className="heading-xl">
                            {contentData.hero?.title || "A Space for Healing"}
                        </h1>
                        <p className={styles.heroDesc} style={{ margin: '1.5rem auto 3rem' }}>
                            {contentData.hero?.subtitle || "Sanctuary for transformation"}
                        </p>
                        <div className={styles.btnGroup} style={{ justifyContent: 'center' }}>
                            <Link href="/contact" className="btn btn-primary" style={{ padding: '1rem 2.5rem', fontSize: '1.1rem' }}>
                                Book Free Consultation <ArrowRight size={18} style={{ marginLeft: '0.5rem' }} />
                            </Link>
                            <Link href="/specialties" className="btn btn-outline" style={{ padding: '1rem 2.5rem', fontSize: '1.1rem' }}>
                                Our Specialities
                            </Link>
                        </div>
                    </motion.div>
                </div>
                {!contentData.hero?.bgImage && <div className={styles.blob} />}
            </section>

            {/* 2. Experience SSHIMOH */}
            <section className="section bg-white" style={{ backgroundColor: 'white' }}>
                <div className="container" style={{ textAlign: 'center' }}>
                    <h2 className="heading-lg">{contentData.experience?.title || "Experience"}</h2>
                    <p style={{ color: 'var(--text-secondary)', maxWidth: '600px', margin: '0 auto 3rem' }}>
                        {contentData.experience?.subtitle || "Take a virtual tour"}
                    </p>
                    <div className={styles.videoPlaceholder}>
                        {contentData.experience?.videoUrl ? (
                            <iframe width="100%" height="100%" src={contentData.experience.videoUrl} frameBorder="0" allowFullScreen></iframe>
                        ) : (
                            <>
                                <div className={styles.playButton} />
                                <p>Facility Overview Video</p>
                            </>
                        )}
                    </div>
                </div>
            </section>

            {/* 3. Our Core Services */}
            <section className="section" style={{ backgroundColor: 'var(--bg-color)' }} id="treatments">
                <div className="container">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '3rem' }}>
                        <h2 className="heading-lg" style={{ marginBottom: 0 }}>Our Core Services</h2>
                        <Link href="/specialties" className={styles.cardLink} style={{ fontSize: '1.1rem' }}>
                            Explore All Services <ArrowRight size={16} />
                        </Link>
                    </div>

                    <div className={styles.grid}>
                        {specialtiesData && specialtiesData.length > 0 ? (
                            specialtiesData.map((service: any, idx: number) => (
                                <motion.div
                                    key={service.id}
                                    className={styles.card}
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    whileInView={{ opacity: 1, scale: 1 }}
                                    viewport={{ once: true }}
                                    transition={{ duration: 0.4, delay: Math.min(idx * 0.1, 0.4) }}
                                >
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem' }}>
                                        <div className={styles.cardIcon} style={{ margin: 0, width: '48px', height: '48px', overflow: 'hidden' }}>
                                            {service.imageUrl ? (
                                                <img src={service.imageUrl} alt={service.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                            ) : (
                                                <Activity size={20} />
                                            )}
                                        </div>
                                        <ArrowRight size={24} color="var(--primary-color)" />
                                    </div>
                                    <h3>{service.name}</h3>
                                    <p style={{ minHeight: '60px' }}>{service.description || "Learn more about our specialized treatment options tailored for your needs."}</p>

                                    <Link href={`/treatments/${service.slug || service.id}`} className="btn" style={{ width: '100%', marginTop: '2rem', backgroundColor: 'var(--primary-light)', color: 'var(--primary-dark)' }}>
                                        View Treatment
                                    </Link>
                                </motion.div>
                            ))
                        ) : (
                            <div style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '3rem', color: 'var(--text-secondary)' }}>
                                No treatments available yet. Please add them in the CMS.
                            </div>
                        )}
                    </div>
                </div>
            </section>

            {/* 4. The SSHIMOH Healing Path */}
            <section className="section" style={{ backgroundColor: 'white' }}>
                <div className="container">
                    <div style={{ textAlign: 'center', marginBottom: '5rem' }}>
                        <h2 className="heading-lg">{contentData.healingPath?.title || "Healing Path"}</h2>
                        <p style={{ color: 'var(--text-secondary)' }}>{contentData.healingPath?.subtitle}</p>
                    </div>

                    <div className={styles.pathGrid}>
                        {(contentData.healingPath?.steps || []).map((step: any, idx: number) => (
                            <motion.div
                                key={idx}
                                className={styles.pathStep}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.5, delay: idx * 0.2 }}
                            >
                                <div className={styles.pathNum}>{step.num}</div>
                                <h4>{step.title}</h4>
                                <p>{step.desc}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* 5. Patient Stories of Hope */}
            <section className="section" style={{ backgroundColor: 'var(--primary-dark)', color: 'white' }}>
                <div className="container" style={{ textAlign: 'center' }}>
                    <h2 className="heading-lg" style={{ color: 'white' }}>{contentData.testimonials?.title || "Patient Stories of Hope"}</h2>
                    <p style={{ color: 'var(--primary-light)', marginBottom: '4rem' }}>{contentData.testimonials?.subtitle}</p>

                    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '3rem', backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 'var(--radius-lg)', border: '1px solid rgba(255,255,255,0.1)' }}>
                        <div style={{ display: 'flex', justifyContent: 'center', gap: '0.25rem', marginBottom: '1.5rem' }}>
                            {[1, 2, 3, 4, 5].map(i => <Star key={i} fill="var(--accent-color)" color="var(--accent-color)" />)}
                        </div>
                        <p style={{ fontSize: '1.25rem', fontStyle: 'italic', lineHeight: 1.8, marginBottom: '2rem' }}>
                            "{contentData.testimonials?.quote}"
                        </p>
                        <p style={{ fontWeight: 600, color: 'var(--accent-color)', letterSpacing: '0.05em', textTransform: 'uppercase' }}>— {contentData.testimonials?.author}</p>
                    </div>
                </div>
            </section>
        </main>
    );
}
