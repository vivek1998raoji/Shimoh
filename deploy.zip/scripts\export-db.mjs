import { PrismaClient } from '@prisma/client';
import fs from 'fs';
import path from 'path';

// Note: This script assumes you run it locally BEFORE changing your DATABASE_URL to Supabase.
// It reads from the local SQLite DB and exports a JSON representation.
// Then you change .env to Supabase, run `npx prisma db push`, and run another script to import.

const prisma = new PrismaClient();

async function exportData() {
    console.log("Exporting data from local SQLite...");

    const doctors = await prisma.doctor.findMany({ include: { specialties: true } });
    const specialties = await prisma.specialty.findMany();
    const pages = await prisma.pageContent.findMany();
    const users = await prisma.user.findMany();

    const exportBundle = {
        doctors,
        specialties,
        pages,
        users
    };

    const outPath = path.join(process.cwd(), 'database_export.json');
    fs.writeFileSync(outPath, JSON.stringify(exportBundle, null, 2));

    console.log(`Successfully exported data to ${outPath}`);
    await prisma.$disconnect();
}

exportData().catch(console.error);
