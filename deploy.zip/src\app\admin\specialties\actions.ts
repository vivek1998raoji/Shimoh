'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

export async function createSpecialty(formData: FormData) {
    const name = formData.get('name') as string;
    const description = formData.get('description') as string;
    const slug = formData.get('slug') as string;
    const imageUrl = formData.get('imageUrl') as string;

    await prisma.specialty.create({
        data: {
            name,
            description,
            slug,
            imageUrl
        }
    });

    revalidatePath('/admin/specialties');
    revalidatePath('/'); // Refresh homepage since it displays them
}

export async function updateSpecialty(formData: FormData) {
    const id = formData.get('id') as string;
    const name = formData.get('name') as string;
    const description = formData.get('description') as string;
    const slug = formData.get('slug') as string;
    const imageUrl = formData.get('imageUrl') as string;

    await prisma.specialty.update({
        where: { id },
        data: {
            name,
            description,
            slug,
            imageUrl
        }
    });

    revalidatePath('/admin/specialties');
    revalidatePath('/');
}

export async function deleteSpecialty(formData: FormData) {
    const id = formData.get('id') as string;
    await prisma.specialty.delete({ where: { id } });
    revalidatePath('/admin/specialties');
    revalidatePath('/');
}
