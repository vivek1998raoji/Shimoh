import { prisma } from '@/lib/prisma';
import { Plus, Edit, Trash2 } from 'lucide-react';
import Link from 'next/link';
import { deleteSpecialty } from './actions';

export default async function AdminSpecialtiesPage() {
    const specialties = await prisma.specialty.findMany({
        orderBy: { name: 'asc' },
    });

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <h1 className="heading-md">Treatments Management</h1>
                <Link href="/admin/specialties/new" className="btn btn-primary" style={{ padding: '0.5rem 1rem', display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                    <Plus size={18} /> Add Treatment
                </Link>
            </div>

            <div className="glass-panel" style={{ padding: '2rem', borderRadius: 'var(--radius-lg)' }}>
                {specialties.length === 0 ? (
                    <p style={{ color: 'var(--text-secondary)' }}>No treatments defined yet.</p>
                ) : (
                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead>
                            <tr style={{ borderBottom: '1px solid var(--glass-border)' }}>
                                <th style={{ padding: '1rem', color: 'var(--text-secondary)' }}>Image</th>
                                <th style={{ padding: '1rem', color: 'var(--text-secondary)' }}>Name (Slug)</th>
                                <th style={{ padding: '1rem', color: 'var(--text-secondary)' }}>Description</th>
                                <th style={{ padding: '1rem', textAlign: 'right', color: 'var(--text-secondary)' }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {specialties.map(spec => (
                                <tr key={spec.id} style={{ borderBottom: '1px solid var(--glass-border)' }}>
                                    <td style={{ padding: '1rem' }}>
                                        {spec.imageUrl ? (
                                            <img src={spec.imageUrl} alt={spec.name} style={{ width: '40px', height: '40px', borderRadius: '4px', objectFit: 'cover' }} />
                                        ) : (
                                            <div style={{ width: '40px', height: '40px', backgroundColor: 'var(--glass-bg)', borderRadius: '4px' }} />
                                        )}
                                    </td>
                                    <td style={{ padding: '1rem' }}>
                                        <div style={{ fontWeight: 500 }}>{spec.name}</div>
                                        <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>/{spec.slug || spec.id}</div>
                                    </td>
                                    <td style={{ padding: '1rem', color: 'var(--text-secondary)', maxWidth: '300px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{spec.description || '-'}</td>
                                    <td style={{ padding: '1rem', textAlign: 'right' }}>
                                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
                                            <Link href={`/admin/specialties/${spec.id}`} className="btn btn-outline" style={{ padding: '0.5rem', color: 'var(--primary-dark)', borderColor: 'var(--glass-border)' }} title="Edit Treatment">
                                                <Edit size={16} />
                                            </Link>
                                            <form action={deleteSpecialty}>
                                                <input type="hidden" name="id" value={spec.id} />
                                                <button type="submit" className="btn" style={{ padding: '0.5rem', backgroundColor: '#fee2e2', color: '#ef4444', border: '1px solid #fca5a5' }} title="Delete Treatment">
                                                    <Trash2 size={16} />
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
}
