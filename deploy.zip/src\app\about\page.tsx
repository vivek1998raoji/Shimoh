import { prisma } from '@/lib/prisma';
import AboutClient from './AboutClient';

export default async function AboutPage() {
    const pageData = await prisma.pageContent.findUnique({
        where: { slug: 'about' }
    });

    return <AboutClient pageData={pageData} />;
}
