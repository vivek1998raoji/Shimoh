import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import styles from "./admin.module.css";
import { LayoutDashboard, FileText, Users, Briefcase, MessageSquare, LogOut, Shield } from "lucide-react";
import LogoutButton from "./LogoutButton";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
    const session = await getServerSession(authOptions);

    if (!session) {
        redirect("/login");
    }

    return (
        <div className={styles.adminContainer}>
            {/* Sidebar */}
            <aside className={styles.sidebar}>
                <div className={styles.sidebarHeader}>
                    <h2>Wellness Admin</h2>
                    <p>Welcome, {session.user?.name}</p>
                </div>

                <nav className={styles.nav}>
                    <Link href="/admin" className={styles.navLink}>
                        <LayoutDashboard size={20} /> Dashboard
                    </Link>
                    <Link href="/admin/content" className={styles.navLink}>
                        <FileText size={20} /> Pages
                    </Link>
                    <Link href="/admin/leads" className={styles.navLink}>
                        <MessageSquare size={20} /> Leads
                    </Link>
                    <Link href="/admin/doctors" className={styles.navLink}>
                        <Users size={20} /> Team / Doctors
                    </Link>
                    <Link href="/admin/specialties" className={styles.navLink}>
                        <Briefcase size={20} /> Treatments
                    </Link>
                    <Link href="/admin/users" className={styles.navLink}>
                        <Shield size={20} /> Users & Auth
                    </Link>
                </nav>

                <div className={styles.sidebarFooter}>
                    <LogoutButton />
                </div>
            </aside>

            {/* Main Content Area */}
            <main className={styles.mainContent}>
                <header className={styles.topHeader}>
                    <div className={styles.breadcrumb}>
                        Dashboard
                    </div>
                    <div>
                        <Link href="/" target="_blank" className="btn btn-outline" style={{ padding: "0.5rem 1rem", fontSize: "0.875rem" }}>
                            View Live Site
                        </Link>
                    </div>
                </header>

                <div className={styles.contentArea}>
                    {children}
                </div>
            </main>
        </div>
    );
}
