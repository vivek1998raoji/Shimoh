'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';

export async function createPage(formData: FormData) {
    const title = formData.get('title')?.toString();
    const slug = formData.get('slug')?.toString();
    const content = formData.get('content')?.toString();

    if (!title || !slug || !content) throw new Error('Missing required fields');

    await prisma.pageContent.create({
        data: { title, slug, content }
    });

    revalidatePath('/admin/content');
    revalidatePath(`/${slug}`);
    redirect('/admin/content');
}

export async function updatePage(id: string, formData: FormData) {
    const title = formData.get('title')?.toString();
    const slug = formData.get('slug')?.toString();
    const content = formData.get('content')?.toString();

    if (!title || !slug || !content) throw new Error('Missing required fields');

    await prisma.pageContent.update({
        where: { id },
        data: { title, slug, content }
    });

    revalidatePath('/admin/content');
    revalidatePath(`/${slug}`);
    redirect('/admin/content');
}
