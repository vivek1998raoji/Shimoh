import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function seedPages() {
    try {
        console.log('Seeding default pages...');

        await prisma.pageContent.upsert({
            where: { slug: 'about' },
            update: {},
            create: {
                slug: 'about',
                title: 'About Us',
                content: `
          <h2 class="heading-md">Our Mission</h2>
          <p style="margin-bottom: '2rem'">
              At SSHIMOH, our mission is to provide compassionate, evidence-based mental healthcare that empowers individuals to reclaim their lives. We believe in holistic healing, treating the mind, body, and spirit in a serene, supportive environment.
          </p>
          <h2 class="heading-md">Our Approach</h2>
          <p>
              We utilize a multi-disciplinary approach, combining advanced psychiatric care with therapeutic modalities tailored to each individual's unique journey. Our team of world-class professionals is dedicated to walking alongside you every step of the way.
          </p>
        `
            }
        });

        await prisma.pageContent.upsert({
            where: { slug: 'contact' },
            update: {},
            create: {
                slug: 'contact',
                title: 'Contact Us',
                content: ``
            }
        });

        console.log('Pages seeded successfully!');
    } catch (err) {
        console.error('Error seeding pages', err);
    } finally {
        await prisma.$disconnect();
    }
}

seedPages();
