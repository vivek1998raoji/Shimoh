import { prisma } from '@/lib/prisma';
import { updateUserPassword, createAdminUser, deleteUser } from './actions';
import { Shield, Key, UserPlus, Trash2 } from 'lucide-react';
import { revalidatePath } from 'next/cache';

export default async function AdminUsersPage() {
    const users = await prisma.user.findMany({
        orderBy: { createdAt: 'asc' }
    });

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <h1 className="heading-md">Admin Users & Profiles</h1>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'minmax(300px, 1fr) 2fr', gap: '2rem' }}>
                {/* Create User Form */}
                <div className="glass-panel" style={{ padding: '2rem', borderRadius: 'var(--radius-lg)', alignSelf: 'start' }}>
                    <h2 className="heading-sm" style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <UserPlus size={20} /> Add New Admin
                    </h2>
                    <form action={createAdminUser} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                        <input type="text" name="name" placeholder="Full Name" required style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)' }} />
                        <input type="text" name="email" placeholder="Email / Username" required style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)' }} />
                        <input type="password" name="password" placeholder="Password (min 6 chars)" minLength={6} required style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)' }} />
                        <button type="submit" className="btn btn-primary" style={{ marginTop: '0.5rem' }}>Create User</button>
                    </form>
                </div>

                {/* List of Users & Password Management */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {users.map(user => (
                        <div key={user.id} className="glass-panel" style={{ padding: '1.5rem', borderRadius: 'var(--radius-lg)' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem' }}>
                                <div>
                                    <h3 style={{ fontSize: '1.25rem', marginBottom: '0.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                        {user.name} <Shield size={16} color="var(--primary-dark)" />
                                    </h3>
                                    <p style={{ color: 'var(--text-secondary)' }}>{user.email}</p>
                                </div>
                                <form action={async () => {
                                    'use server';
                                    await deleteUser(user.id);
                                }}>
                                    <button type="submit" className="btn" style={{ padding: '0.5rem', backgroundColor: '#fee2e2', color: '#ef4444', border: '1px solid #fca5a5' }} title="Delete User">
                                        <Trash2 size={16} />
                                    </button>
                                </form>
                            </div>

                            <form action={updateUserPassword} style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                                <input type="hidden" name="id" value={user.id} />
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flex: 1 }}>
                                    <Key size={16} color="var(--text-secondary)" />
                                    <input
                                        type="password"
                                        name="newPassword"
                                        placeholder="New Password"
                                        required
                                        minLength={6}
                                        style={{ padding: '0.5rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)', flex: 1 }}
                                    />
                                </div>
                                <button type="submit" className="btn btn-outline" style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}>
                                    Update Password
                                </button>
                            </form>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
