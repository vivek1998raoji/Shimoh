import type { Metadata } from 'next'
import './globals.css'
import { Providers } from './providers'
import Header from '@/components/Header'
import Footer from '@/components/Footer'

export const metadata: Metadata = {
  title: 'Mind & Wellness | Inner Peace Therapy',
  description: 'Premium holistic therapy and mental wellness organization focusing on finding inner peace.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <Providers>
          <Header />
          <div style={{ paddingTop: '80px', minHeight: 'calc(100vh - 100px)' }}>
            {children}
          </div>
          <Footer />
        </Providers>
      </body>
    </html>
  )
}
