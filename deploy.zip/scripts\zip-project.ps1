$sourcePath = "c:\Users\Vivek\.gemini\antigravity\playground\radiant-triangulum"
$destinationPath = "c:\Users\Vivek\.gemini\antigravity\playground\radiant-triangulum\deploy.zip"

If (Test-Path $destinationPath) {
    Remove-Item $destinationPath
}

Add-Type -AssemblyName System.IO.Compression.FileSystem

$excludeFolders = @(".git", "node_modules", ".next")
$files = Get-ChildItem -Path $sourcePath -Recurse | Where-Object {
    $exclude = $false
    foreach ($folder in $excludeFolders) {
        if ($_.FullName -match "\\$folder\\") {
            $exclude = $true
            break
        }
        if ($_.Name -eq $folder -and $_.PSIsContainer) {
            $exclude = $true
            break
        }
    }
    $exclude -eq $false
}

$tempDir = Join-Path $env:TEMP "sshimoh-deploy-temp"
If (Test-Path $tempDir) { Remove-Item -Recurse -Force $tempDir }
New-Item -ItemType Directory -Force -Path $tempDir | Out-Null

foreach ($file in $files) {
    $relativePath = $file.FullName.Substring($sourcePath.Length + 1)
    $targetPath = Join-Path $tempDir $relativePath
    
    if ($file.PSIsContainer) {
        if (-not (Test-Path $targetPath)) {
            New-Item -ItemType Directory -Force -Path $targetPath | Out-Null
        }
    } else {
        $parentDir = Split-Path $targetPath
        if (-not (Test-Path $parentDir)) {
            New-Item -ItemType Directory -Force -Path $parentDir | Out-Null
        }
        Copy-Item -Path $file.FullName -Destination $targetPath -Force
    }
}

[System.IO.Compression.ZipFile]::CreateFromDirectory($tempDir, $destinationPath)
Remove-Item -Recurse -Force $tempDir

Write-Host "Created $destinationPath"
