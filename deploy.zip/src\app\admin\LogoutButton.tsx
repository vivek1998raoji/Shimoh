'use client';

import { signOut } from 'next-auth/react';
import { LogOut } from 'lucide-react';
import styles from './admin.module.css';

export default function LogoutButton() {
    return (
        <button onClick={() => signOut()} className={styles.navLink} style={{ width: '100%', background: 'transparent', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
            <LogOut size={20} /> Logout
        </button>
    );
}
